CREATE PROCEDURE add_order_data(IN n INT)
  BEGIN    
  DECLARE i INT DEFAULT 1;  
	DECLARE oderChildId varchar(64);
	DECLARE orderId varchar(64);
    WHILE (i <= n ) DO  	
			set orderId = round(round(rand(),12)*1000000000000);
			set oderChildId = round(round(rand(),12)*1000000000000);
			insert into m_order(order_id, create_time, close_time, payment_time, user_id,user_phone, payment_type, count,is_pay, total, close, del_status)
			values(orderId,now(),now(),null,'5437087a-2246-4638-ba7e-31c67891ea77','123',null,666,0,100,0,0);
			insert into m_order_detail (order_id, order_child_id,product_id, person_id, report_id,status, physical_time, close_time)
			values(orderId,oderChildId,'53283530337',null,null,0,NOW(),null);
			set oderChildId = round(round(rand(),12)*1000000000000);
			insert into m_order_detail (order_id, order_child_id,product_id, person_id, report_id,status, physical_time, close_time)
			values(orderId,oderChildId,'517133056668',null,null,0,NOW(),null);
			set i=i+1;  
    END WHILE;  
END;
