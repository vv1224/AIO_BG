CREATE PROCEDURE insertHospitalId()
  BEGIN
declare i int;
    set i=0;
    while i<575 do
    insert into t_hospital_community(hospital_id) values(26);
    set i=i+1;
    end while;
END;
