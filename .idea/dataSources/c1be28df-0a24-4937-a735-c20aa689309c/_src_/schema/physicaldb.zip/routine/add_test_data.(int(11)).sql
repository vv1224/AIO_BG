CREATE PROCEDURE add_test_data(IN n INT)
  BEGIN    
  DECLARE i INT DEFAULT 1;  
	DECLARE id varchar(64);
	DECLARE oderChildId varchar(64);
	DECLARE userId varchar(64);
	DECLARE productId varchar(64);
	DECLARE orderId varchar(64);
	DECLARE reportId int;
	DECLARE personId int;
	DECLARE phone varchar(64);
    WHILE (i <= n ) DO  	
		  set id = UUID();
			set productId = round(round(rand(),12)*1000000000000);
			set orderId = round(round(rand(),12)*1000000000000);
			set oderChildId = round(round(rand(),12)*1000000000000);
			set userId = UUID();
			set reportId = i;
			set personId = i;
			-- 用户
			insert into m_user(user_id, name, phone,password, user_type, del_status,create_time)
      values (id, CONCAT('user',i), phone,'123456', 1, 0, now());
			insert into m_user(user_id, name, phone,password, user_type, del_status,create_time)
      values (userId, CONCAT('user',i), phone,'123456', 0, 0, now());
			-- 用户角色
			insert into m_user_role(user_id,role_id,create_time,user_type) values(id,2,now(),0);
			-- 体检人
			insert into m_person(id,name,sex,age,marital_status,id_no,phone,user_id) values(personId,CONCAT('person',i),0,18,0,'1234245522','13501233',userId);
			-- 报告单
			insert into m_reportmake(id,description,image_url,person_id,create_time) values(reportId,'这是图片说明','20170510405816.pdf',personId,now());
			-- 商品
			INSERT INTO m_product (product_id,name,type_id,user_id,price, original,grounding,target_sex,image_url,description)
			values(productId,CONCAT('product',i),2,id,(3+i)*2,null,0,2,'20170514147176.jpg','商品说明');
			
			-- 订单 0：待付款 1：待预约 2：待体检 3：已完成  4：已取消
			if i%4 = 0
				then 
					insert into m_order(order_id, create_time, close_time, payment_time, user_id,user_phone, payment_type, count,is_pay, total, close, del_status)
					values(orderId,now(),null,null,id,'13501233',null,666,0,100,0,0);
					insert into m_order_detail (order_id, order_child_id,product_id, person_id, report_id,status, physical_time, close_time)
					values(orderId,oderChildId,productId,personId,reportId,0,NOW(),null);
			 ELSEIF i%4 = 1
				then 
					insert into m_order(order_id, create_time, close_time, payment_time, user_id,user_phone, payment_type, count,is_pay, total, close, del_status)
					values(orderId,NOW(),null,NOW(),id,'135012333',0,666,1,6000,0,0);
					insert into m_order_detail (order_id, order_child_id,product_id, person_id, report_id,status, physical_time, close_time)
					values(orderId,oderChildId,productId,personId,reportId,1,NOW(),null);
			 ELSEIF i%4 = 2
				then
					insert into m_order(order_id, create_time, close_time, payment_time, user_id,user_phone, payment_type, count,is_pay, total, close, del_status)
					values(orderId,NOW(),null,NOW(),id,'135012333',1,666,1,400,0,0);
					insert into m_order_detail (order_id, order_child_id,product_id, person_id, report_id,status, physical_time, close_time)
					values(orderId,oderChildId,productId,personId,reportId,2,NOW(),null);
			 ELSE 
					insert into m_order(order_id, create_time, close_time, payment_time, user_id,user_phone, payment_type, count,is_pay, total, close, del_status)
					values(orderId,NOW(),NOW(),NOW(),id,'135012333',0,666,1,54354,1,0);
					insert into m_order_detail (order_id, order_child_id,product_id, person_id, report_id,status, physical_time, close_time)
					values(orderId,oderChildId,productId,personId,reportId,3,NOW(),null);
			 END IF;
				set i=i+1;  
    END WHILE;  
END;
