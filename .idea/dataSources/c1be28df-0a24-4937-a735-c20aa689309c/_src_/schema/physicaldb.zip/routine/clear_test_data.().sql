CREATE PROCEDURE clear_test_data()
  BEGIN 
	delete from m_order_detail;
	delete from m_order;
	delete from m_person;
	delete from m_product;
	delete from m_reportmake;
	delete from m_user where name <> 'admin@qq';
	delete from m_user_role where user_id not in ('6b37087a-2246-4638-ba7e-31ca7b51ea77','5437087a-2246-4638-ba7e-31c67891ea77');
END;
